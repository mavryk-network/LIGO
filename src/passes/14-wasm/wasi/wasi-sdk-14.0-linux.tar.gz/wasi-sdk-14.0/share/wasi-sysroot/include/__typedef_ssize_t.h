#ifndef __wasilibc___typedef_ssize_t_h
#define __wasilibc___typedef_ssize_t_h

/* This is defined to be the same size as size_t. */
typedef long ssize_t;

#endif
