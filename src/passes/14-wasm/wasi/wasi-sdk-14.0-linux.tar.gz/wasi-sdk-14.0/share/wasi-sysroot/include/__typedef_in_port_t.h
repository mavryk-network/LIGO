#ifndef __wasilibc___typedef_in_port_t_h
#define __wasilibc___typedef_in_port_t_h

typedef unsigned short in_port_t;

#endif
